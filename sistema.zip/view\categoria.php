<html>
    <head>
        <title>Cadastro de categoria</title>
        <link rel="stylesheet" href="../css/estilos.css">
    </head>
    <body>
        <form action="../control/categoriaControl.php?a=1" method="post">
        <h1>Cadastro de categoria</h1>
            <label for='id'>id</label>
<input type='text' name='id'><br>
<label for='descricao'>descricao</label>
<input type='text' name='descricao'><br>

             <button type="submit">Enviar</button>
        </form>
    </body>
</html>